﻿CREATE DATABASE HyperBeastTesth
GO
USE HyperBeastTesth
GO

create table  DANH_MUC
(
	MaDM int IDENTITY primary key ,
	TenDanhMuc nvarchar(50) not null,
	TrangThai bit not null
)
GO

CREATE TABLE SAN_PHAM
(
	MaSP int IDENTITY,
	TenSP NVARCHAR(100),
	NgayNhap VARCHAR(20),
	NgayCapNhat VARCHAR(20),
	TrangThai NVARCHAR(30),
	MaDM int,
	PRIMARY KEY (MaSP),
	FOREIGN KEY (MaDM) REFERENCES DANH_MUC(MaDM)
)
GO



CREATE TABLE CHAT_LIEU_DE_GIAY(
	MaCLDe INT IDENTITY NOT NULL PRIMARY KEY,
	TenChatLieuDe NVARCHAR(40),
	TrangThai BIT,
)
GO

CREATE TABLE SIZE(
	MaSize INT IDENTITY NOT NULL PRIMARY KEY,
	KichThuoc INT,
	TrangThai BIT,
)
GO

CREATE TABLE MAU_SAC(
	MaMS INT IDENTITY NOT NULL PRIMARY KEY,
	TenMau NVARCHAR(20),
	TrangThai BIT
)
GO

CREATE TABLE CHAT_LIEU(
	MaCL INT IDENTITY NOT NULL PRIMARY KEY,
	TenChatLieu NVARCHAR(40),
	TrangThai BIT,
)
GO


create TABLE CHI_TIET_SAN_PHAM
(
	MaCTSP int IDENTITY,
	DonGia FLOAT,
	SoLuong INT,
	MaSP int,
	MaCLDe int,
	MaSize INT,
	MaMS INT,
	MaCL INT,
	MaBarCode NVARCHAR(13),
	TenAnh NVARCHAR(225),
	MoTa NVARCHAR(100),
	PRIMARY KEY (MaCTSP),
	FOREIGN KEY (MaSP) REFERENCES SAN_PHAM(MaSP),
	FOREIGN KEY (MaCLDe) REFERENCES CHAT_LIEU_DE_GIAY(MaCLDe),
	FOREIGN KEY (MaSize) REFERENCES SIZE(MaSize),
	FOREIGN KEY (MaMS) REFERENCES MAU_SAC(MaMS),
	FOREIGN KEY (MaCL) REFERENCES CHAT_LIEU(MaCL)
)
GO



create table TAI_KHOAN(
	MaTK int IDENTITY primary key,
	TenDangNhap varchar(50) not null,
	MatKhau varchar(8) not null,
	HoTen	nvarchar(50) not null,
	GioiTinh bit not null,
	DienThoai varchar(10) not null,
	Email nvarchar(50) not null,
	DiaChi nvarchar(100) not null,
	NgayTao VARCHAR(20) not null,
	NgayCapNhat date not null,
	ChucVu Nvarchar(30) not null,
	TrangThai bit
)
GO

CREATE TABLE THONG_TIN_KH
(
	MaTTKH int IDENTITY,
	TenKH NVARCHAR(50),
	SDT VARCHAR(10),
	NgayTao DATE,
	NgayCN DATE,
	TrangThai bit
	PRIMARY KEY (MaTTKH)
)
GO

create table HOA_DON(
	MaHD int IDENTITY primary key,
	NgayTao VARCHAR(20),
	NgayCapNhat VARCHAR(20),
	TrangThai Nvarchar(40),
	TongTien float,
	MaTTKH int,
	MaTK INT not null,
	foreign key (MaTTKH) references  THONG_TIN_KH(MaTTKH),
	foreign key (MaTK) references  TAI_KHOAN(MaTK),
)
GO
ALTER TABLE HOA_DON
ADD GhiChu NVARCHAR(255);

--ALTER TABLE HOA_DON
--ALTER COLUMN NgayCapNhat varchar(30)


create table HOA_DON_CHI_TIET
(
	MaHDCT int IDENTITY primary key,
	MaCTSP INT,
	MaHD int,
	SoLuong INT,
	DonGia FLOAT,
	TrangThai NVARCHAR(30),
	GhiChu NVARCHAR (70),
	HDCT int,
	foreign key (MaCTSP) references  CHI_TIET_SAN_PHAM(MaCTSP),
	foreign key (MaHD) references  HOA_DON(MaHD),
)
go
--ALTER TABLE HOA_DON_CHI_TIET
--add FOREIGN KEY(MaHDCT) REFERENCES HOA_DON_CHI_TIET (HDCT)

CREATE table LICH_SU_HOA_DON(
	MaLSHD int IDENTITY primary key,
	NgayTaoHoaDon date,
	MaHD INT not null,
	MaTK INT not null,
	foreign key(MaHD) references HOA_DON(MaHD),
	foreign key(MaTK) references TAI_KHOAN(MaTK)
)
go

CREATE table THANH_TOAN(
	MaTT int IDENTITY primary key,
	HinhThucThanhToan nvarchar(20) not null,
	MaTTKH int,
	MaHD int,
	foreign key(MaHD) references HOA_DON(MaHD),
	foreign key(MaTTKH) references THONG_TIN_KH(MaTTKH)
)
go


CREATE TABLE KHUYEN_MAI
(
	MaKM int IDENTITY,
	TenKhuyenMai NVARCHAR(100),
	NgayBD DATE,
	NgayKT DATE,
	MucGiam FLOAT,
	MaGiam NVARCHAR(8),
	DonVi bit,
	TrangThai BIT,
	PRIMARY KEY (MaKM)
)
GO

CREATE TABLE HOA_DON_KHUYEN_MAI
(
	MaHDKM int IDENTITY PRIMARY KEY,
	MaKM int,
	MaHD int NOT NULL,
	SoTienConlai FLOAT,
	foreign key(MaKM) references KHUYEN_MAI(MaKM),
	foreign key(MaHD) references HOA_DON(MaHD)
)
GO

create table DOI_TRA
(
	MaDT int IDENTITY primary key,
	MaHDCT int,
	LyDoDoi nvarchar(100) not null,
	NgayDoiTra date ,
	TrangThai bit not null,
	MoTa nvarchar(100) not null,
	foreign key (MaHDCT) references HOA_DON_CHI_TIET(MaHDCT)
)
go

create table SAN_PHAM_LOI
(
	MaSPL int IDENTITY primary key,
	TenLoi nvarchar(50) not null,
	MoTa nvarchar(100) not null,
	MaHDCT int,
	SoLuongSPLoi int,
	foreign key (MaHDCT) references HOA_DON_CHI_TIET(MaHDCT)
)
GO

INSERT INTO DANH_MUC(TenDanhMuc, TrangThai )
VALUES ('Nike Jordan', 1)
INSERT INTO DANH_MUC(TenDanhMuc, TrangThai )
VALUES ('Nike Air Max', 1)
INSERT INTO DANH_MUC(TenDanhMuc, TrangThai)
VALUES ('Nike Zoom', 1)
INSERT INTO DANH_MUC(TenDanhMuc, TrangThai)
VALUES ('Nike Air Force', 1)
INSERT INTO DANH_MUC(TenDanhMuc, TrangThai)
VALUES ('Nike Flyknit', 1)
go


INSERT INTO SAN_PHAM(TenSP,  NgayNhap, NgayCapNhat, TrangThai, MaDM)
VALUES ('Air Jordan 1', '04-11-2023','04-11-2023',N'Đang kinh doanh',1)
INSERT INTO SAN_PHAM(TenSP, NgayNhap, NgayCapNhat, TrangThai,MaDM)
VALUES ('Jordan Stadium 90', '04-11-2023','04-11-2023',N'Đang kinh doanh',1)
INSERT INTO SAN_PHAM(TenSP, NgayNhap, NgayCapNhat, TrangThai,MaDM )
VALUES ('Air Force 1', '04-11-2023','04-11-2023',N'Đang kinh doanh',4)
INSERT INTO SAN_PHAM(TenSP, NgayNhap, NgayCapNhat, TrangThai,MaDM )
VALUES ('Air Max 97', '04-11-2023','04-11-2023',N'Đang kinh doanh', 2)
INSERT INTO SAN_PHAM(TenSP, NgayNhap, NgayCapNhat, TrangThai,MaDM )
VALUES ('Nike Streakfly', '04-11-2023','04-11-2023',N'Đang kinh doanh', 3)
INSERT INTO SAN_PHAM(TenSP, NgayNhap, NgayCapNhat, TrangThai,MaDM )
VALUES ('Air Max 90', '04-11-2023','04-11-2023',N'Đang kinh doanh', 2)
GO

INSERT INTO CHI_TIET_SAN_PHAM( MaSP,SoLuong, DonGia, MaMS, MaSize,MaCL,MaCLDe,MaBarCode,TenAnh, MoTa)
VALUES (1,5,3669000 ,3,5,1,1,'0411230513669', 'Air_Jordan_1_Mid.png', null)
INSERT INTO CHI_TIET_SAN_PHAM( MaSP,SoLuong, DonGia, MaMS, MaSize,MaCL,MaCLDe,MaBarCode,TenAnh, MoTa)
VALUES (2,2,4109000,5,5,2,1,'0411230711401', 'Jordan_Stadium_90.png', null)
INSERT INTO CHI_TIET_SAN_PHAM( MaSP,SoLuong, DonGia, MaMS, MaSize,MaCL,MaCLDe,MaBarCode,TenAnh, MoTa)
VALUES (3,10,2998000,3,4,1,1,'0411231012998', 'Nike_Air_Force_1.png', null)
INSERT INTO CHI_TIET_SAN_PHAM( MaSP,SoLuong, DonGia, MaMS, MaSize,MaCL,MaCLDe,MaBarCode,TenAnh, MoTa)
VALUES (4,6,5270000,4,6,1,4,'0411230615270', 'Nike_Air_Max_97.png', null)
INSERT INTO CHI_TIET_SAN_PHAM( MaSP,SoLuong, DonGia, MaMS, MaSize,MaCL,MaCLDe,MaBarCode,TenAnh, MoTa)
VALUES (5,3,4699000,4,3,3,3,'0411230314699', 'Nike_Streakfly.png', null)
INSERT INTO CHI_TIET_SAN_PHAM( MaSP,SoLuong, DonGia, MaMS, MaSize,MaCL,MaCLDe,MaBarCode,TenAnh, MoTa)
VALUES (6,5,4699000,4,5,1,4,'0411230514699', 'Nike_Air_Max_90_GORE-TEX.png', null)
GO

select * from CHI_TIET_SAN_PHAM

INSERT INTO MAU_SAC(TenMau, TrangThai)
VALUES(N'Xanh Dương',1);
INSERT INTO MAU_SAC(TenMau, TrangThai)
VALUES(N'Đỏ',1);
INSERT INTO MAU_SAC(TenMau, TrangThai)
VALUES(N'Trắng',1);
INSERT INTO MAU_SAC(TenMau, TrangThai)
VALUES(N'Đen',1);
INSERT INTO MAU_SAC(TenMau, TrangThai)
VALUES(N'Nâu',1);
go

INSERT INTO SIZE(KichThuoc,TrangThai)
VALUES(24,1)
INSERT INTO SIZE(KichThuoc,TrangThai)
VALUES(25,1)
INSERT INTO SIZE(KichThuoc,TrangThai)
VALUES(26,1)
INSERT INTO SIZE(KichThuoc,TrangThai)
VALUES(27,1)
INSERT INTO SIZE(KichThuoc,TrangThai)
VALUES(28,1)
INSERT INTO SIZE(KichThuoc,TrangThai)
VALUES(29,1)
INSERT INTO SIZE(KichThuoc,TrangThai)
VALUES(30,1)
INSERT INTO SIZE(KichThuoc,TrangThai)
VALUES(31,1)
INSERT INTO SIZE(KichThuoc,TrangThai)
VALUES(32,1)
INSERT INTO SIZE(KichThuoc,TrangThai)
VALUES(33,1)
INSERT INTO SIZE(KichThuoc,TrangThai)
VALUES(34,1)
go

INSERT INTO CHAT_LIEU(TenChatLieu,TrangThai)
VALUES(N'Da bóng',1)
INSERT INTO CHAT_LIEU(TenChatLieu,TrangThai)
VALUES(N'Da lộn',1)
INSERT INTO CHAT_LIEU(TenChatLieu,TrangThai)
VALUES(N'Lưới',1)
INSERT INTO CHAT_LIEU(TenChatLieu,TrangThai)
VALUES(N'Vải',1)
go

INSERT INTO CHAT_LIEU_DE_GIAY(TenChatLieuDe, TrangThai)
VALUES(N'Cao su mềm', 1)
INSERT INTO CHAT_LIEU_DE_GIAY(TenChatLieuDe, TrangThai)
VALUES(N'Cao su cứng', 1)
INSERT INTO CHAT_LIEU_DE_GIAY(TenChatLieuDe, TrangThai)
VALUES(N'Bọt', 1)
INSERT INTO CHAT_LIEU_DE_GIAY(TenChatLieuDe, TrangThai)
VALUES(N'Khí', 1)
GO


--chạy sẵn câu lệnh hóa đơn hoặc nhấn tạo hóa đơn mới trong form
insert into HOA_DON(NgayTao, NgayCapNhat, TrangThai,MaTK)
values('23-11-2023', '23-11-2023', N'Chờ thanh toán', 2)
--thêm thông tin khách hàng mẫu
insert into THONG_TIN_KH(TenKH, SDT, NgayTao, NgayCN, TrangThai)
values (N'Hoàng Anh', '0328343389', '07-12-2023','07-12-2023', 0);
insert into THONG_TIN_KH(TenKH, SDT, NgayTao, NgayCN, TrangThai)
values (N'Diễm Quỳnh', '0328343381', '07-12-2023','07-12-2023', 1);
insert into THONG_TIN_KH(TenKH, SDT, NgayTao, NgayCN, TrangThai)
values (N'Vương Tuấn', '0328343382', '07-12-2023','07-12-2023', 1);
insert into THONG_TIN_KH(TenKH, SDT, NgayTao, NgayCN, TrangThai)
values (N'Tiến Hoàng', '0328343383', '07-12-2023','07-12-2023', 1);

-- chạy câu lệnh tài khoản trước
insert into TAI_KHOAN(TenDangNhap, MatKhau, HoTen, GioiTinh, DienThoai, Email, DiaChi, NgayTao, NgayCapNhat, ChucVu, trangThai)
values('Admin123', '12345678', N'Nhóm 5', 1, '0328343379','nhom5@fpt.edu.vn', N'Hà Nội', '2023-11-23', '2023-11-23', N'Nhân viên',1)
insert into TAI_KHOAN(TenDangNhap, MatKhau, HoTen, GioiTinh, DienThoai, Email, DiaChi, NgayTao, NgayCapNhat, ChucVu, trangThai)
values('anhknh', '12345678', N'Hoàng Anh', 1, '0328343386','anhknh@fpt.edu.vn', N'Hà Nội', '2023-11-23', '2023-11-23', N'Quan ly',1)

select*from TAI_KHOAN
--chạy sẵn câu lệnh hóa đơn hoặc nhấn tạo hóa đơn mới trong form
insert into HOA_DON(NgayTao, NgayCapNhat, TrangThai,MaTK)
values('23-11-2023', '23-11-2023', N'Chờ thanh toán', 3)

--thêm thông tin khách hàng mẫu
insert into THONG_TIN_KH(TenKH, SDT, NgayTao, NgayCN, TrangThai)
values (N'Hoàng Anh', '0328343389', '07-12-2023','07-12-2023', 0);
insert into THONG_TIN_KH(TenKH, SDT, NgayTao, NgayCN, TrangThai)
values (N'Diễm Quỳnh', '0328343381', '07-12-2023','07-12-2023', 1);
insert into THONG_TIN_KH(TenKH, SDT, NgayTao, NgayCN, TrangThai)
values (N'Vương Tuấn', '0328343382', '07-12-2023','07-12-2023', 1);
insert into THONG_TIN_KH(TenKH, SDT, NgayTao, NgayCN, TrangThai)
values (N'Tiến Hoàng', '0328343383', '07-12-2023','07-12-2023', 1);

-- khuyến mại mẫu
insert into KHUYEN_MAI(TenKhuyenMai, NgayBD, NgayKT, MucGiam, MaGiam, TrangThai, DonVi)
values(N'Black Friday', '11-30-2023', '12-05-2023', 100000, N'BFHYPERB',1, 0)
insert into KHUYEN_MAI(TenKhuyenMai, NgayBD, NgayKT, MucGiam, MaGiam, TrangThai, DonVi)
values(N'Teacher Day', '11-20-2023', '11-25-2023', 10, N'TDHYPERB',0, 1)
